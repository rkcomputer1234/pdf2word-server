
async function convertPDF() {
  const fileInput = document.getElementById("pdfFile");
  const status = document.getElementById("status");
  if (fileInput.files.length === 0) {
    alert("Please select a PDF file.");
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  status.textContent = "Uploading and converting...";

  try {
    const response = await fetch("https://your-render-api-url.onrender.com/convert", {
      method: "POST",
      body: formData
    });

    if (!response.ok) throw new Error("Conversion failed");

    const blob = await response.blob();
    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = "converted.docx";
    link.click();

    status.textContent = "Conversion successful!";
  } catch (err) {
    status.textContent = "Error: " + err.message;
  }
}
